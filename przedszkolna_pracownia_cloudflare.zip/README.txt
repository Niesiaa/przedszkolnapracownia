PRZEDSZKOLNA PRACOWNIA - PAKIET DO CLOUDFLARE PAGES

1. Wejdź do Cloudflare Pages.
2. Wybierz Direct Upload / Drag and Drop.
3. Wgraj cały ten plik ZIP albo zawartość folderu.
4. Główny plik strony to index.html.
5. Po publikacji możesz podłączyć własną domenę.
